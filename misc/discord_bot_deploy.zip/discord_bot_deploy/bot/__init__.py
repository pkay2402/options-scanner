"""
Discord Options Trading Bot
Provides options analysis commands via Discord using Schwab API
"""

__version__ = "1.0.0"
