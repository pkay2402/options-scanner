#!/bin/bash
# Discord Bot Startup Script for PythonAnywhere

# Navigate to bot directory
cd "$(dirname "$0")"

# Activate virtual environment (adjust path as needed)
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# Run bot
python3 bot/main.py >> bot.log 2>&1
