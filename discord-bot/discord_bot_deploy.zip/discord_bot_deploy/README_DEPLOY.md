# Discord Bot Deployment Package

## Quick Start

1. **Upload to PythonAnywhere**
   - Upload this entire folder to ~/discord-bot/

2. **Create Virtual Environment**
   ```bash
   cd ~/discord-bot
   python3.10 -m venv venv
   source venv/bin/activate
   ```

3. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure Environment**
   - Copy .env.template to .env
   - Fill in your Discord bot token and Schwab credentials
   - Verify schwab_client.json exists and has valid tokens

5. **Test Run**
   ```bash
   python3 bot/main.py
   ```
   Press Ctrl+C to stop

6. **Keep Running (Always-On Task)**
   - PythonAnywhere Dashboard → Tasks → Add new always-on task
   - Command: `/home/yourusername/discord-bot/start_bot.sh`

## Files Included

- bot/ - Discord bot code
- src/ - Schwab API client
- schwab_client.json - Token file (KEEP SECURE!)
- requirements.txt - Python dependencies
- .env.template - Environment variables template
- start_bot.sh - Startup script

## Troubleshooting

**View Logs:**
```bash
tail -f ~/discord-bot/bot.log
```

**Check Process:**
```bash
ps aux | grep python
```

**Stop Bot:**
```bash
pkill -f "bot/main.py"
```

## Token Refresh

Schwab refresh tokens expire after 7 days. If bot stops authenticating:
1. Run bot locally to refresh tokens
2. Copy updated schwab_client.json to server
3. Restart bot
